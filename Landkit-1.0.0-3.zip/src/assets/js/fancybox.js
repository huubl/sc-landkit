//
// fancybox.js
// Theme module
//

(function() {
  
  // Global options

  $.fancybox.defaults.image.preload = false;
  $.fancybox.defaults.toolbar = false;
  $.fancybox.defaults.clickContent = false;

})();